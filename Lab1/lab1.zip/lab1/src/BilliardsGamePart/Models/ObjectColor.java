package BilliardsGamePart.Models;

public enum ObjectColor {
    Red,
    Blue,
    Black
}
