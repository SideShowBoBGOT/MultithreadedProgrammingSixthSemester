package BilliardsGamePart.Models;

public enum ObjectBehaviour {
    Straight,
    Randomized
}
