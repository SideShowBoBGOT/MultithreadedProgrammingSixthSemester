package BilliardsGamePart.Models;

public enum ObjectType {
    Ball,
    Hole
}
