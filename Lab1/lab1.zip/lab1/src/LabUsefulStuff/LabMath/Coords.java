package LabUsefulStuff.LabMath;

public enum Coords {
    X,
    Y
}
